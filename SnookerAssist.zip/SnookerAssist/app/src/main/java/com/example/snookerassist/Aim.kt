package com.example.snookerassist

import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin
import kotlin.math.sqrt

/** kind: 0 = cue ball to contact, 1 = struck ball, 2 = cue ball after contact, 3 = knock-on balls */
data class Seg(val x0: Float, val y0: Float, val x1: Float, val y1: Float, val kind: Int)

/** [ring] = where the cue ball will be at the moment of contact (x, y, radius), or null if nothing is hit. */
class Prediction(val segs: List<Seg>, val ring: FloatArray?)

object Aim {
    /**
     * Follows the game's aim line: finds the first ball it hits, then rolls the struck ball and
     * the cue ball on with equal-mass elastic maths (no spin or friction). Paths bounce off a
     * cushion at most once, stop in pockets, follow up to two knock-on collisions, and are
     * length-limited (the game doesn't tell us the shot power, so these are "where it heads").
     */
    fun predict(s: Scene): Prediction? {
        val theta = s.aim ?: return null
        val cueIdx = s.balls.indexOfFirst { it.kind == Kind.CUE }
        if (cueIdx < 0) return null
        val cue = s.balls[cueIdx]
        val sim = Sim(s, cue.r * 2f)
        sim.run(cue.x, cue.y, cos(theta), sin(theta), cue.r, setOf(cueIdx), 0, 0, 0, sim.budget(0))
        val ring = if (sim.hit) floatArrayOf(sim.cx, sim.cy, cue.r) else null
        return Prediction(sim.segs, ring)
    }

    private class Sim(val s: Scene, val pocketR: Float) {
        val segs = ArrayList<Seg>()
        var hit = false; var cx = 0f; var cy = 0f
        private val tableW = s.inset / 0.019f          // inset was defined as 1.9% of the table width

        fun budget(kind: Int): Float = when (kind) {
            0 -> 1.5f * tableW
            1 -> 0.6f * tableW
            2 -> 0.45f * tableW
            else -> 0.3f * tableW
        }

        private fun maxBounces(kind: Int) = if (kind == 3) 0 else 1

        fun run(
            px: Float, py: Float, dx: Float, dy: Float, rm: Float, ign: Set<Int>,
            depth: Int, bounces: Int, kind: Int, left: Float
        ) {
            // nearest ball
            var tb = Float.MAX_VALUE; var bj = -1
            for (i in s.balls.indices) {
                if (i in ign) continue
                val b = s.balls[i]
                val fx = px - b.x; val fy = py - b.y; val rr = rm + b.r
                val bq = fx * dx + fy * dy; val cq = fx * fx + fy * fy - rr * rr
                val disc = bq * bq - cq
                if (disc < 0f) continue
                val t = -bq - sqrt(disc)
                if (t > 1e-3f && t < tb) { tb = t; bj = i }
            }
            // nearest cushion
            var tc = Float.MAX_VALUE; var na = 0f; var nb = 0f
            for (e in s.edges) {
                val den = e[0] * dx + e[1] * dy
                if (den >= -1e-9f) continue
                val t = (rm + s.inset - (e[0] * px + e[1] * py + e[2])) / den
                if (t > 1e-3f && t < tc) { tc = t; na = e[0]; nb = e[1] }
            }
            // pocket on the way
            var tp = Float.MAX_VALUE
            for (p in s.pockets) {
                val t = (p.x - px) * dx + (p.y - py) * dy
                if (t <= 0f) continue
                val perp = abs((p.x - px) * dy - (p.y - py) * dx)
                if (perp < pocketR && t < tp) tp = t
            }

            val t = minOf(tb, tc, tp)
            if (t >= left) {                                      // runs out of distance first
                segs.add(Seg(px, py, px + dx * left, py + dy * left, kind)); return
            }
            val qx = px + dx * t; val qy = py + dy * t
            segs.add(Seg(px, py, qx, qy, kind))
            val rem = left - t

            if (t == tp) return                                   // potted
            if (t == tc) {                                        // cushion bounce
                if (bounces >= maxBounces(kind)) return
                val dd = dx * na + dy * nb
                run(qx, qy, dx - 2 * dd * na, dy - 2 * dd * nb, rm, ign, depth, bounces + 1, kind, rem)
                return
            }
            // ball-ball collision
            val b = s.balls[bj]
            var nx = b.x - qx; var ny = b.y - qy
            val len = hypot(nx, ny); if (len < 1e-6f) return
            nx /= len; ny /= len
            if (depth == 0) { hit = true; cx = qx; cy = qy }
            if (depth >= 2) return
            val dn = dx * nx + dy * ny
            val tx = dx - dn * nx; val ty = dy - dn * ny
            val tm = hypot(tx, ty)
            val ign2 = ign + bj
            val kHit = if (depth == 0) 1 else 3
            val kDef = if (depth == 0) 2 else 3
            run(b.x, b.y, nx, ny, b.r, ign2, depth + 1, 0, kHit, budget(kHit))
            if (tm > 0.05f) run(qx, qy, tx / tm, ty / tm, rm, ign2, depth + 1, 0, kDef, budget(kDef))
        }
    }
}
