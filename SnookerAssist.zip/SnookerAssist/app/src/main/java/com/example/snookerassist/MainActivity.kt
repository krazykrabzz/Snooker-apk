package com.example.snookerassist

import android.app.Activity
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val reqCapture = 1
    private lateinit var info: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 2)
        }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(48, 96, 48, 48)
        }
        fun btn(label: String, onClick: () -> Unit) = Button(this).apply {
            text = label; setOnClickListener { onClick() }
        }
        info = TextView(this).apply { textSize = 16f }
        col.addView(info)
        col.addView(btn("1. Allow overlay") { openOverlaySettings() })
        col.addView(btn("2. Start") {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Overlay permission is OFF. Turn it on, then come back and tap Start.", Toast.LENGTH_LONG).show()
                openOverlaySettings()
                return@btn
            }
            val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            startActivityForResult(mpm.createScreenCaptureIntent(), reqCapture)
        })
        col.addView(btn("Stop") {
            stopService(Intent(this, OverlayService::class.java))
            Toast.makeText(this, "Stopped", Toast.LENGTH_SHORT).show()
        })
        setContentView(col)
    }

    override fun onResume() {
        super.onResume()
        val on = Settings.canDrawOverlays(this)
        info.text = "Snooker Assist\n\n" +
            "Overlay permission: " + (if (on) "ON" else "OFF (tap button 1 and turn it on)") + "\n\n" +
            "1. Allow overlay\n" +
            "2. Start, choose ENTIRE SCREEN, then open the game.\n\n" +
            "While it runs you will see a magenta frame around the screen and a status line at the top-left. " +
            "It only recognises the default green cloth table."
    }

    private fun openOverlaySettings() {
        startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != reqCapture) return
        if (resultCode == RESULT_OK && data != null) {
            val i = Intent(this, OverlayService::class.java)
                .putExtra("code", resultCode).putExtra("data", data)
            startForegroundService(i)
            Toast.makeText(this, "Started. Open the game now.", Toast.LENGTH_LONG).show()
            moveTaskToBack(true)
        } else {
            Toast.makeText(this, "Screen share was cancelled. Tap Start and allow it.", Toast.LENGTH_LONG).show()
        }
    }
}
