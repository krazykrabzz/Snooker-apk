package com.example.snookerassist

import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

enum class Kind { CUE, RED, OTHER }
data class Ball(val x: Float, val y: Float, val r: Float, val kind: Kind)
data class Pocket(val x: Float, val y: Float)
data class Scene(val balls: List<Ball>, val pockets: List<Pocket>, val w: Int, val h: Int)

private class Blob {
    var n = 0; var sx = 0L; var sy = 0L
    var x0 = Int.MAX_VALUE; var x1 = -1; var y0 = Int.MAX_VALUE; var y1 = -1
    var r = 0L; var g = 0L; var b = 0L
    var minD = Float.MAX_VALUE
}

/**
 * Detector tuned against a real Real Snooker 3D screenshot (angled camera).
 *
 *  1. cloth  = bright green pixels (largest connected piece, so HUD specks are ignored)
 *  2. table  = convex hull of the cloth
 *  3. pockets = gaps in the cushions: non-green, non-saturated pixels inside the hull
 *               that touch the hull edge
 *  4. balls  = saturated non-green blobs inside the hull (each keeps its own radius,
 *               since perspective makes near balls much bigger than far ones)
 *  5. cue ball = round white blob sitting on cloth
 */
class Detector {
    private var stack = IntArray(0)

    /** px: packed RGB (0xRRGGBB) at reduced resolution. */
    fun detect(px: IntArray, w: Int, h: Int): Scene? {
        val n = w * h
        if (stack.size < n) stack = IntArray(n)

        // ---- 1. cloth ----
        val raw = BooleanArray(n)
        for (i in 0 until n) {
            val c = px[i]
            val r = (c shr 16) and 255; val g = (c shr 8) and 255; val b = c and 255
            if (g > r + 20 && g > b + 10 && g > 60) raw[i] = true
        }
        val cloth = keepLargest(raw, w, h) ?: return null

        // ---- 2. table hull from the per-row extremes of the cloth ----
        val pts = ArrayList<IntArray>()
        var minX = w; var maxX = -1; var minY = h; var maxY = -1
        for (y in 0 until h) {
            var xl = -1; var xr = -1
            for (x in 0 until w) if (cloth[y * w + x]) { if (xl < 0) xl = x; xr = x }
            if (xl >= 0) {
                pts.add(intArrayOf(xl, y)); pts.add(intArrayOf(xr, y))
                if (xl < minX) minX = xl; if (xr > maxX) maxX = xr
                if (y < minY) minY = y; if (y > maxY) maxY = y
            }
        }
        if (pts.size < 6 || maxX - minX < w / 4 || maxY - minY < h / 6) return null
        val hull = convexHull(pts)
        if (hull.size < 3) return null

        // half-planes (a,b,c) with a*x+b*y+c = signed distance, positive inside
        val edges = ArrayList<FloatArray>()
        var gx = 0f; var gy = 0f
        for (v in hull) { gx += v[0]; gy += v[1] }
        gx /= hull.size; gy /= hull.size
        for (i in hull.indices) {
            val p = hull[i]; val q = hull[(i + 1) % hull.size]
            val dx = (q[0] - p[0]).toFloat(); val dy = (q[1] - p[1]).toFloat()
            val len = sqrt(dx * dx + dy * dy)
            if (len < 1e-3f) continue
            val a = -dy / len; val b = dx / len
            edges.add(floatArrayOf(a, b, -(a * p[0] + b * p[1])))
        }
        if (edges.size < 3) return null
        var centre = Float.MAX_VALUE
        for (e in edges) centre = min(centre, e[0] * gx + e[1] * gy + e[2])
        if (centre < 0f) for (e in edges) { e[0] = -e[0]; e[1] = -e[1]; e[2] = -e[2] }
        val ne = edges.size
        val ea = FloatArray(ne) { edges[it][0] }
        val eb = FloatArray(ne) { edges[it][1] }
        val ec = FloatArray(ne) { edges[it][2] }

        val dist = FloatArray(n) { -1f }            // -1 = outside the hull
        for (y in minY..maxY) for (x in minX..maxX) {
            var d = Float.MAX_VALUE
            var k = 0
            while (k < ne) {
                val v = ea[k] * x + eb[k] * y + ec[k]
                if (v < d) d = v
                if (d < 0f) break
                k++
            }
            if (d >= 0f) dist[y * w + x] = d
        }

        val uiL = (w * 0.07).toInt(); val uiR = (w * 0.93).toInt(); val uiB = (h * 0.93).toInt()

        // ---- 3. pockets: unsaturated gaps touching the hull edge ----
        val band = 0.05f * w
        val notch = BooleanArray(n)
        for (i in 0 until n) {
            val d = dist[i]
            if (d < 0f || d > band || cloth[i]) continue
            val c = px[i]
            val r = (c shr 16) and 255; val g = (c shr 8) and 255; val b = c and 255
            if (max(r, max(g, b)) - min(r, min(g, b)) < 80) notch[i] = true
        }
        val pockets = ArrayList<Pocket>()
        for (bl in blobs(open4(notch, w, h), px, w, h, dist)) {
            if (bl.n < 12 || bl.minD > 2.5f) continue
            val cx = bl.sx.toFloat() / bl.n; val cy = bl.sy.toFloat() / bl.n
            if (cx < uiL || cx > uiR || cy > uiB) continue
            pockets.add(Pocket(cx, cy))
        }

        // ---- 4/5. ball masks ----
        val colored = BooleanArray(n)
        val white = BooleanArray(n)
        for (y in 0..uiB) for (x in uiL..uiR) {
            val i = y * w + x
            if (dist[i] < 0f || cloth[i]) continue
            val c = px[i]
            val r = (c shr 16) and 255; val g = (c shr 8) and 255; val b = c and 255
            if (r > 200 && b > 200 && g < 80) continue            // our own magenta overlay
            val mx = max(r, max(g, b)); val mn = min(r, min(g, b))
            val sp = mx - mn
            if (mn >= 100 && sp < 45) { if (dist[i] > 3f) white[i] = true; continue }   // grey/white cue ball
            if (mx >= 60 && sp >= 80) colored[i] = true
        }
        val maxR = w * 0.05f
        val balls = ArrayList<Ball>()

        for (bl in blobs(colored, px, w, h, null)) {
            if (bl.n < 4) continue
            val bwid = bl.x1 - bl.x0 + 1; val bhei = bl.y1 - bl.y0 + 1
            val aspect = bwid.toFloat() / bhei
            val fill = bl.n.toFloat() / (bwid * bhei)
            val rad = (bwid + bhei) / 4f
            if (aspect !in 0.55f..1.8f || fill !in 0.45f..0.95f || rad > maxR) continue
            val ar = bl.r.toFloat() / bl.n; val ag = bl.g.toFloat() / bl.n; val ab = bl.b.toFloat() / bl.n
            val kind = if (ar > 0f && ab / ar < 0.3f && ag / ar < 0.42f) Kind.RED else Kind.OTHER
            balls.add(Ball(bl.sx.toFloat() / bl.n, bl.sy.toFloat() / bl.n, rad, kind))
        }

        // cue ball: erode once so the thin white aim line disappears, keep round blobs on cloth
        var cue: Ball? = null
        for (bl in blobs(erode4(white, w, h), px, w, h, null)) {
            if (bl.n < 6) continue
            val bwid = bl.x1 - bl.x0 + 1; val bhei = bl.y1 - bl.y0 + 1
            val aspect = bwid.toFloat() / bhei
            val fill = bl.n.toFloat() / (bwid * bhei)
            val rad = (bwid + bhei) / 4f + 1f
            if (aspect !in 0.6f..1.6f || fill !in 0.5f..0.95f || rad > maxR) continue
            val cx = bl.sx.toFloat() / bl.n; val cy = bl.sy.toFloat() / bl.n
            if (clothRing(cloth, w, h, cx, cy, rad * 1.8f + 2f) < 0.5f) continue
            if (cue == null || rad > cue.r) cue = Ball(cx, cy, rad, Kind.CUE)
        }
        if (cue != null) balls.add(cue)

        return Scene(balls, pockets, w, h)
    }

    // ---------------------------------------------------------------- helpers

    private fun clothRing(cloth: BooleanArray, w: Int, h: Int, cx: Float, cy: Float, rr: Float): Float {
        var hit = 0
        for (k in 0 until 16) {
            val a = k * (Math.PI.toFloat() * 2f / 16f)
            val x = (cx + rr * cos(a)).toInt(); val y = (cy + rr * sin(a)).toInt()
            if (x in 0 until w && y in 0 until h && cloth[y * w + x]) hit++
        }
        return hit / 16f
    }

    private fun keepLargest(mask: BooleanArray, w: Int, h: Int): BooleanArray? {
        val label = IntArray(w * h)
        var best = 0; var bestN = 0; var cur = 0
        for (s in mask.indices) {
            if (!mask[s] || label[s] != 0) continue
            cur++
            var sp = 0; var cnt = 0
            stack[sp++] = s; label[s] = cur
            while (sp > 0) {
                val i = stack[--sp]; cnt++
                val x = i % w; val y = i / w
                if (x > 0 && mask[i - 1] && label[i - 1] == 0) { label[i - 1] = cur; stack[sp++] = i - 1 }
                if (x < w - 1 && mask[i + 1] && label[i + 1] == 0) { label[i + 1] = cur; stack[sp++] = i + 1 }
                if (y > 0 && mask[i - w] && label[i - w] == 0) { label[i - w] = cur; stack[sp++] = i - w }
                if (y < h - 1 && mask[i + w] && label[i + w] == 0) { label[i + w] = cur; stack[sp++] = i + w }
            }
            if (cnt > bestN) { bestN = cnt; best = cur }
        }
        if (best == 0) return null
        val out = BooleanArray(w * h)
        for (i in out.indices) out[i] = label[i] == best
        return out
    }

    private fun convexHull(pts: List<IntArray>): List<IntArray> {
        val p = pts.sortedWith(compareBy({ it[0] }, { it[1] }))
        fun cross(o: IntArray, a: IntArray, b: IntArray): Long =
            (a[0] - o[0]).toLong() * (b[1] - o[1]) - (a[1] - o[1]).toLong() * (b[0] - o[0])
        val lower = ArrayList<IntArray>()
        for (q in p) {
            while (lower.size >= 2 && cross(lower[lower.size - 2], lower[lower.size - 1], q) <= 0) lower.removeAt(lower.size - 1)
            lower.add(q)
        }
        val upper = ArrayList<IntArray>()
        for (q in p.asReversed()) {
            while (upper.size >= 2 && cross(upper[upper.size - 2], upper[upper.size - 1], q) <= 0) upper.removeAt(upper.size - 1)
            upper.add(q)
        }
        lower.removeAt(lower.size - 1); upper.removeAt(upper.size - 1)
        return lower + upper
    }

    private fun erode4(m: BooleanArray, w: Int, h: Int): BooleanArray {
        val o = BooleanArray(w * h)
        for (y in 1 until h - 1) for (x in 1 until w - 1) {
            val i = y * w + x
            if (m[i] && m[i - 1] && m[i + 1] && m[i - w] && m[i + w]) o[i] = true
        }
        return o
    }

    private fun dilate4(m: BooleanArray, w: Int, h: Int): BooleanArray {
        val o = BooleanArray(w * h)
        for (y in 1 until h - 1) for (x in 1 until w - 1) {
            val i = y * w + x
            if (m[i]) { o[i] = true; o[i - 1] = true; o[i + 1] = true; o[i - w] = true; o[i + w] = true }
        }
        return o
    }

    private fun open4(m: BooleanArray, w: Int, h: Int) = dilate4(erode4(m, w, h), w, h)

    /** Connected components (4-neighbour). Consumes [mask]. [dist] optionally tracks min hull distance. */
    private fun blobs(mask: BooleanArray, px: IntArray, w: Int, h: Int, dist: FloatArray?): List<Blob> {
        val out = ArrayList<Blob>()
        for (start in mask.indices) {
            if (!mask[start]) continue
            val bl = Blob()
            var sp = 0
            stack[sp++] = start; mask[start] = false
            while (sp > 0) {
                val i = stack[--sp]
                val x = i % w; val y = i / w
                bl.n++; bl.sx += x; bl.sy += y
                if (x < bl.x0) bl.x0 = x; if (x > bl.x1) bl.x1 = x
                if (y < bl.y0) bl.y0 = y; if (y > bl.y1) bl.y1 = y
                val c = px[i]
                bl.r += (c shr 16) and 255; bl.g += (c shr 8) and 255; bl.b += c and 255
                if (dist != null && dist[i] < bl.minD) bl.minD = dist[i]
                if (x > 0 && mask[i - 1]) { mask[i - 1] = false; stack[sp++] = i - 1 }
                if (x < w - 1 && mask[i + 1]) { mask[i + 1] = false; stack[sp++] = i + 1 }
                if (y > 0 && mask[i - w]) { mask[i - w] = false; stack[sp++] = i - w }
                if (y < h - 1 && mask[i + w]) { mask[i + w] = false; stack[sp++] = i + w }
            }
            out.add(bl)
        }
        return out
    }
}
