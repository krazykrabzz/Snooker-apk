package com.example.snookerassist

import kotlin.math.max
import kotlin.math.min

enum class Kind { CUE, RED, OTHER }
data class Ball(val x: Float, val y: Float, val r: Float, val kind: Kind)
data class Pocket(val x: Float, val y: Float)
data class Scene(
    val balls: List<Ball>, val pockets: List<Pocket>,
    val w: Int, val h: Int, val box: IntArray
)

private class Blob {
    var n = 0; var sx = 0L; var sy = 0L
    var x0 = Int.MAX_VALUE; var x1 = -1; var y0 = Int.MAX_VALUE; var y1 = -1
    var r = 0L; var g = 0L; var b = 0L
}

class Detector {

    /** px: packed RGB (0xRRGGBB) at reduced resolution. */
    fun detect(px: IntArray, w: Int, h: Int): Scene? {
        val cloth = BooleanArray(w * h)
        val colSum = IntArray(w)
        val rowSum = IntArray(h)
        for (y in 0 until h) for (x in 0 until w) {
            val c = px[y * w + x]
            val r = (c shr 16) and 255; val g = (c shr 8) and 255; val b = c and 255
            if (g > r + 20 && g > b + 10 && g > 60) {
                cloth[y * w + x] = true; colSum[x]++; rowSum[y]++
            }
        }
        val x0 = colSum.indexOfFirst { it > h * 0.15 }
        val x1 = colSum.indexOfLast { it > h * 0.15 }
        val y0 = rowSum.indexOfFirst { it > w * 0.15 }
        val y1 = rowSum.indexOfLast { it > w * 0.15 }
        if (x0 < 0 || y0 < 0 || x1 - x0 < w / 4 || y1 - y0 < h / 6) return null
        val bw = x1 - x0; val bh = y1 - y0
        val box = intArrayOf(x0, y0, x1, y1)

        // --- balls: non-cloth, reasonably bright pixels inside the table ---
        // Ignore the outer 7% of the screen on each side (game UI buttons live there).
        val uiX0 = (w * 0.07).toInt(); val uiX1 = (w * 0.93).toInt()
        val mx = (bw * 0.03).toInt(); val my = (bh * 0.03).toInt()
        val ix0 = max(x0 + mx, uiX0); val ix1 = min(x1 - mx, uiX1)
        val iy0 = y0 + my; val iy1 = y1 - my
        if (ix1 - ix0 < 10 || iy1 - iy0 < 10) return null

        val ballMask = BooleanArray(w * h)
        for (y in iy0..iy1) for (x in ix0..ix1) {
            val i = y * w + x
            if (cloth[i]) continue
            val c = px[i]
            val r = (c shr 16) and 255; val g = (c shr 8) and 255; val b = c and 255
            if ((r + g + b) / 3 < 70) continue
            if (r > 200 && b > 200 && g < 80) continue   // skip our own magenta overlay
            ballMask[i] = true
        }
        // Erode once so thin things (the game's aim line, the cue stick) vanish
        // instead of merging into the cue-ball blob.
        val eroded = BooleanArray(w * h)
        for (y in iy0 + 1 until iy1) for (x in ix0 + 1 until ix1) {
            val i = y * w + x
            if (ballMask[i] && ballMask[i - 1] && ballMask[i + 1] && ballMask[i - w] && ballMask[i + w]) eroded[i] = true
        }

        // Balls look much bigger near the camera than far away, so there is no
        // single "ball size" filter: each blob keeps its own radius.
        val maxR = bw * 0.05f
        val balls = ArrayList<Ball>()
        for (bl in blobs(eroded, px, w, h)) {
            val bwid = bl.x1 - bl.x0 + 1; val bhei = bl.y1 - bl.y0 + 1
            val aspect = bwid.toFloat() / bhei
            val fill = bl.n.toFloat() / (bwid * bhei)
            val rad = (bwid + bhei) / 4f + 1f            // +1 undoes the erosion
            if (bl.n < 3 || aspect !in 0.6f..1.6f || fill !in 0.5f..0.95f || rad > maxR) continue
            val ar = bl.r / bl.n; val ag = bl.g / bl.n; val ab = bl.b / bl.n
            val spread = max(ar, max(ag, ab)) - min(ar, min(ag, ab))
            val kind = when {
                (ar + ag + ab) / 3 > 170 && spread < 50 -> Kind.CUE
                ar > 140 && ag < 100 && ab < 100 -> Kind.RED
                else -> Kind.OTHER
            }
            balls.add(Ball(bl.sx.toFloat() / bl.n + 0f, bl.sy.toFloat() / bl.n, rad, kind))
        }

        // --- pockets: the two far corners = ends of the top cushion ---
        val rowEnd = min(h - 1, y0 + max(2, bh / 60))
        var fl = w; var fr = -1
        for (y in y0..rowEnd) for (x in 0 until w) {
            if (cloth[y * w + x]) { if (x < fl) fl = x; if (x > fr) fr = x }
        }
        val pockets = if (fr > fl) listOf(Pocket(fl.toFloat(), y0.toFloat()), Pocket(fr.toFloat(), y0.toFloat()))
        else emptyList()

        return Scene(balls, pockets, w, h, box)
    }

    private fun blobs(mask: BooleanArray, px: IntArray, w: Int, h: Int): List<Blob> {
        val out = ArrayList<Blob>()
        val stack = IntArray(w * h)
        for (start in mask.indices) {
            if (!mask[start]) continue
            val bl = Blob()
            var sp = 0
            stack[sp++] = start; mask[start] = false
            while (sp > 0) {
                val i = stack[--sp]
                val x = i % w; val y = i / w
                bl.n++; bl.sx += x; bl.sy += y
                if (x < bl.x0) bl.x0 = x; if (x > bl.x1) bl.x1 = x
                if (y < bl.y0) bl.y0 = y; if (y > bl.y1) bl.y1 = y
                val c = px[i]
                bl.r += (c shr 16) and 255; bl.g += (c shr 8) and 255; bl.b += c and 255
                if (x > 0 && mask[i - 1]) { mask[i - 1] = false; stack[sp++] = i - 1 }
                if (x < w - 1 && mask[i + 1]) { mask[i + 1] = false; stack[sp++] = i + 1 }
                if (y > 0 && mask[i - w]) { mask[i - w] = false; stack[sp++] = i - w }
                if (y < h - 1 && mask[i + w]) { mask[i + w] = false; stack[sp++] = i + w }
            }
            out.add(bl)
        }
        return out
    }
}
