package com.example.snookerassist

import kotlin.math.max
import kotlin.math.min

enum class Kind { CUE, RED, OTHER }
data class Ball(val x: Float, val y: Float, val r: Float, val kind: Kind)
data class Pocket(val x: Float, val y: Float)
data class Scene(val balls: List<Ball>, val pockets: List<Pocket>, val w: Int, val h: Int)

private class Blob {
    var n = 0; var sx = 0L; var sy = 0L
    var x0 = Int.MAX_VALUE; var x1 = -1; var y0 = Int.MAX_VALUE; var y1 = -1
    var r = 0L; var g = 0L; var b = 0L
}

class Detector {

    /** px: packed RGB (0xRRGGBB) at reduced resolution. */
    fun detect(px: IntArray, w: Int, h: Int): Scene? {
        val cloth = BooleanArray(w * h)
        val colSum = IntArray(w)
        val rowSum = IntArray(h)
        for (y in 0 until h) for (x in 0 until w) {
            val c = px[y * w + x]
            val r = (c shr 16) and 255; val g = (c shr 8) and 255; val b = c and 255
            if (g > r + 20 && g > b + 10 && g > 60) {
                cloth[y * w + x] = true; colSum[x]++; rowSum[y]++
            }
        }
        val x0 = colSum.indexOfFirst { it > h * 0.15 }
        val x1 = colSum.indexOfLast { it > h * 0.15 }
        val y0 = rowSum.indexOfFirst { it > w * 0.15 }
        val y1 = rowSum.indexOfLast { it > w * 0.15 }
        if (x0 < 0 || y0 < 0 || x1 - x0 < w / 4 || y1 - y0 < h / 6) return null
        val bw = x1 - x0; val bh = y1 - y0

        // --- balls: non-cloth, reasonably bright pixels inside the table ---
        val mx = (bw * 0.03).toInt(); val my = (bh * 0.03).toInt()
        val ix0 = x0 + mx; val ix1 = x1 - mx; val iy0 = y0 + my; val iy1 = y1 - my
        val ballMask = BooleanArray(w * h)
        for (y in iy0..iy1) for (x in ix0..ix1) {
            val i = y * w + x
            if (cloth[i]) continue
            val c = px[i]
            val r = (c shr 16) and 255; val g = (c shr 8) and 255; val b = c and 255
            if ((r + g + b) / 3 < 70) continue
            if (r > 200 && b > 200 && g < 80) continue   // skip our own magenta overlay
            ballMask[i] = true
        }
        val minArea = max(12, (w * h) / 40000)
        val cand = blobs(ballMask, px, w, h).filter {
            val bwid = it.x1 - it.x0 + 1; val bhei = it.y1 - it.y0 + 1
            val aspect = bwid.toFloat() / bhei
            val fill = it.n.toFloat() / (bwid * bhei)
            it.n >= minArea && aspect in 0.6f..1.6f && fill in 0.5f..0.95f
        }
        if (cand.isEmpty()) return null
        val radii = cand.map { ((it.x1 - it.x0 + 1) + (it.y1 - it.y0 + 1)) / 4f }.sorted()
        val medR = radii[radii.size / 2]

        val balls = ArrayList<Ball>()
        for (bl in cand) {
            val rad = ((bl.x1 - bl.x0 + 1) + (bl.y1 - bl.y0 + 1)) / 4f
            if (rad < medR * 0.6f || rad > medR * 1.5f) continue
            val ar = bl.r / bl.n; val ag = bl.g / bl.n; val ab = bl.b / bl.n
            val spread = max(ar, max(ag, ab)) - min(ar, min(ag, ab))
            val kind = when {
                (ar + ag + ab) / 3 > 170 && spread < 50 -> Kind.CUE
                ar > 140 && ag < 100 && ab < 100 -> Kind.RED
                else -> Kind.OTHER
            }
            balls.add(Ball(bl.sx.toFloat() / bl.n, bl.sy.toFloat() / bl.n, rad, kind))
        }

        // --- pockets: big dark blobs hugging the table edge ---
        val padX = (bw * 0.06).toInt(); val padY = (bh * 0.06).toInt()
        val px0 = max(0, x0 - padX); val px1 = min(w - 1, x1 + padX)
        val py0 = max(0, y0 - padY); val py1 = min(h - 1, y1 + padY)
        val darkMask = BooleanArray(w * h)
        for (y in py0..py1) for (x in px0..px1) {
            val c = px[y * w + x]
            if ((((c shr 16) and 255) + ((c shr 8) and 255) + (c and 255)) / 3 < 45) darkMask[y * w + x] = true
        }
        val ballArea = Math.PI.toFloat() * medR * medR
        val pockets = blobs(darkMask, px, w, h)
            .filter { it.n > ballArea * 1.2f }
            .map { Pocket(it.sx.toFloat() / it.n, it.sy.toFloat() / it.n) }
            .filter { it.x < ix0 || it.x > ix1 || it.y < iy0 || it.y > iy1 }
            .take(6)
        val finalPockets = if (pockets.size >= 4) pockets else listOf(
            Pocket(x0.toFloat(), y0.toFloat()), Pocket((x0 + x1) / 2f, y0.toFloat()), Pocket(x1.toFloat(), y0.toFloat()),
            Pocket(x0.toFloat(), y1.toFloat()), Pocket((x0 + x1) / 2f, y1.toFloat()), Pocket(x1.toFloat(), y1.toFloat())
        )
        return Scene(balls, finalPockets, w, h)
    }

    private fun blobs(mask: BooleanArray, px: IntArray, w: Int, h: Int): List<Blob> {
        val out = ArrayList<Blob>()
        val stack = IntArray(w * h)
        for (start in mask.indices) {
            if (!mask[start]) continue
            val bl = Blob()
            var sp = 0
            stack[sp++] = start; mask[start] = false
            while (sp > 0) {
                val i = stack[--sp]
                val x = i % w; val y = i / w
                bl.n++; bl.sx += x; bl.sy += y
                if (x < bl.x0) bl.x0 = x; if (x > bl.x1) bl.x1 = x
                if (y < bl.y0) bl.y0 = y; if (y > bl.y1) bl.y1 = y
                val c = px[i]
                bl.r += (c shr 16) and 255; bl.g += (c shr 8) and 255; bl.b += c and 255
                if (x > 0 && mask[i - 1]) { mask[i - 1] = false; stack[sp++] = i - 1 }
                if (x < w - 1 && mask[i + 1]) { mask[i + 1] = false; stack[sp++] = i + 1 }
                if (y > 0 && mask[i - w]) { mask[i - w] = false; stack[sp++] = i - w }
                if (y < h - 1 && mask[i + w]) { mask[i + w] = false; stack[sp++] = i + w }
            }
            out.add(bl)
        }
        return out
    }
}
