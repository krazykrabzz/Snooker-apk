package com.example.snookerassist

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.View

/**
 * Everything here is pure magenta with anti-aliasing OFF, so the detector can recognise
 * (and ignore) its own drawing when it shows up in the screen capture.
 */
class OverlayView(ctx: Context) : View(ctx) {
    var pred: Prediction? = null
    var scene: Scene? = null
    var status: String = ""
    var fw = 1
    var fh = 1

    private fun pen(w: Float) = Paint().apply {
        color = Color.MAGENTA; strokeWidth = w; style = Paint.Style.STROKE; isAntiAlias = false
    }
    private val frame = pen(8f)
    private val thick = pen(6f)
    private val thin = pen(3f)
    private val text = Paint().apply { color = Color.MAGENTA; textSize = 30f; isAntiAlias = false }

    override fun onDraw(c: Canvas) {
        c.drawRect(4f, 4f, width - 4f, height - 4f, frame)
        c.drawText(status, 330f, 60f, text)
        val sx = width.toFloat() / fw
        val sy = height.toFloat() / fh

        if (DEBUG) scene?.let { s ->
            for (b in s.balls) c.drawCircle(b.x * sx, b.y * sy, b.r * sx * 1.5f + 4f, thin)
            for (p in s.pockets) c.drawCircle(p.x * sx, p.y * sy, 14f, thin)
        }

        val p = pred ?: return
        for (s in p.segs) {
            c.drawLine(s.x0 * sx, s.y0 * sy, s.x1 * sx, s.y1 * sy, if (s.kind == 3) thin else thick)
        }
        p.ring?.let { c.drawCircle(it[0] * sx, it[1] * sy, it[2] * sx, thick) }   // where the cue ball touches
    }

    companion object { const val DEBUG = false }   // true draws a circle on every detected ball/pocket
}
