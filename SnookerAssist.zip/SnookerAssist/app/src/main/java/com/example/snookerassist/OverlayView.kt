package com.example.snookerassist

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.View

class OverlayView(ctx: Context) : View(ctx) {
    var shot: Shot? = null
    var scene: Scene? = null
    var status: String = ""
    var fw = 1
    var fh = 1
    private val thick = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.MAGENTA; strokeWidth = 6f; style = Paint.Style.STROKE
    }
    private val frame = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.MAGENTA; strokeWidth = 8f; style = Paint.Style.STROKE
    }
    private val thin = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.MAGENTA; strokeWidth = 2f; style = Paint.Style.STROKE
    }
    private val text = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.MAGENTA; textSize = 30f
    }

    override fun onDraw(c: Canvas) {
        c.drawRect(4f, 4f, width - 4f, height - 4f, frame)
        c.drawText(status, 24f, 150f, text)   // live status line (shows what the detector sees)
        val sx = width.toFloat() / fw
        val sy = height.toFloat() / fh
        if (DEBUG) scene?.let { s ->
            // everything debug is magenta so the detector ignores it
            for (b in s.balls) {
                c.drawCircle(b.x * sx, b.y * sy, b.r * sx * 1.5f + 4f, thin)
                val tag = when (b.kind) { Kind.CUE -> "C"; Kind.RED -> "R"; else -> "o" }
                c.drawText(tag, b.x * sx - 8f, b.y * sy - b.r * sx * 1.5f - 10f, text)
            }
            for (p in s.pockets) c.drawCircle(p.x * sx, p.y * sy, 14f, thin)
        }
        val s = shot ?: return
        c.drawLine(s.cue.x * sx, s.cue.y * sy, s.ghostX * sx, s.ghostY * sy, thick)
        c.drawLine(s.target.x * sx, s.target.y * sy, s.pocket.x * sx, s.pocket.y * sy, thick)
        c.drawCircle(s.ghostX * sx, s.ghostY * sy, s.target.r * sx, thick)
    }

    companion object { const val DEBUG = true }   // set false to hide detection markers
}
