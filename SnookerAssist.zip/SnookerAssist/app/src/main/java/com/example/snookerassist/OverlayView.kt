package com.example.snookerassist

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.View

/**
 * Everything here is pure magenta with anti-aliasing OFF, so the detector can recognise
 * (and ignore) its own drawing when it shows up in the screen capture.
 */
class OverlayView(ctx: Context) : View(ctx) {
    var shots: List<Shot> = emptyList()
    var scene: Scene? = null
    var status: String = ""
    var fw = 1
    var fh = 1

    private fun pen(w: Float) = Paint().apply {
        color = Color.MAGENTA; strokeWidth = w; style = Paint.Style.STROKE; isAntiAlias = false
    }
    private val frame = pen(8f)
    private val thick = pen(6f)
    private val thin = pen(3f)
    private val text = Paint().apply { color = Color.MAGENTA; textSize = 30f; isAntiAlias = false }

    override fun onDraw(c: Canvas) {
        c.drawRect(4f, 4f, width - 4f, height - 4f, frame)
        c.drawText(status, 330f, 60f, text)
        val sx = width.toFloat() / fw
        val sy = height.toFloat() / fh

        if (DEBUG) scene?.let { s ->
            for (b in s.balls) c.drawCircle(b.x * sx, b.y * sy, b.r * sx * 1.5f + 4f, thin)
            for (p in s.pockets) c.drawCircle(p.x * sx, p.y * sy, 14f, thin)
        }

        // every reachable ball: the line it will roll along to its pocket
        for ((i, s) in shots.withIndex()) {
            c.drawLine(s.target.x * sx, s.target.y * sy, s.pocket.x * sx, s.pocket.y * sy, if (i == 0) thick else thin)
        }
        // the best shot also shows where to aim the cue ball
        shots.firstOrNull()?.let { s ->
            c.drawLine(s.cue.x * sx, s.cue.y * sy, s.ghostX * sx, s.ghostY * sy, thick)
            c.drawCircle(s.ghostX * sx, s.ghostY * sy, s.target.r * sx, thick)
        }
    }

    companion object { const val DEBUG = false }   // true draws a circle on every detected ball/pocket
}
