package com.example.snookerassist

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.View

class OverlayView(ctx: Context) : View(ctx) {
    var shot: Shot? = null
    var fw = 1
    var fh = 1
    private val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.MAGENTA; strokeWidth = 5f; style = Paint.Style.STROKE
    }

    override fun onDraw(c: Canvas) {
        val s = shot ?: return
        val sx = width.toFloat() / fw
        val sy = height.toFloat() / fh
        c.drawLine(s.cue.x * sx, s.cue.y * sy, s.ghostX * sx, s.ghostY * sy, line)
        c.drawLine(s.target.x * sx, s.target.y * sy, s.pocket.x * sx, s.pocket.y * sy, line)
        c.drawCircle(s.ghostX * sx, s.ghostY * sy, s.target.r * sx, line)
    }
}
