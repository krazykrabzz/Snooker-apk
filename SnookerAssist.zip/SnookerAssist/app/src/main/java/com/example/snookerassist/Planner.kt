package com.example.snookerassist

import kotlin.math.hypot

data class Shot(
    val cue: Ball, val target: Ball, val pocket: Pocket,
    val ghostX: Float, val ghostY: Float, val score: Float
)

object Planner {
    /**
     * Ghost-ball method in screen space, using each ball's own on-screen radius.
     * Returns up to [k] shots, at most one per target ball (its best pocket), best first.
     */
    fun top(s: Scene, k: Int): List<Shot> {
        val cue = s.balls.filter { it.kind == Kind.CUE }.maxByOrNull { it.r } ?: return emptyList()
        val others = s.balls.filter { it !== cue }
        if (others.isEmpty() || s.pockets.isEmpty()) return emptyList()
        val diag = hypot(s.w.toFloat(), s.h.toFloat())
        val found = ArrayList<Shot>()

        for (t in others) {
            var best: Shot? = null
            for (p in s.pockets) {
                val dx = p.x - t.x; val dy = p.y - t.y
                val d = hypot(dx, dy); if (d < 1e-3f) continue
                val ux = dx / d; val uy = dy / d
                val gap = cue.r + t.r
                val gx = t.x - ux * gap; val gy = t.y - uy * gap           // ghost ball centre
                val cx = gx - cue.x; val cy = gy - cue.y
                val cd = hypot(cx, cy); if (cd < 1e-3f) continue
                val cosCut = (cx * ux + cy * uy) / cd                      // 1 = straight on
                if (cosCut < 0.17f) continue                               // cut beyond ~80 deg
                val blockers = others.filter { it !== t }
                if (!clear(cue.x, cue.y, gx, gy, blockers, cue.r)) continue
                if (!clear(t.x, t.y, p.x, p.y, blockers, t.r)) continue
                val score = cosCut - 0.5f * (cd + d) / diag
                if (best == null || score > best.score) best = Shot(cue, t, p, gx, gy, score)
            }
            if (best != null) found.add(best)
        }
        found.sortByDescending { it.score }
        return found.take(k)
    }

    private fun clear(ax: Float, ay: Float, bx: Float, by: Float, balls: List<Ball>, moverR: Float): Boolean {
        val vx = bx - ax; val vy = by - ay
        val len2 = vx * vx + vy * vy
        for (b in balls) {
            val t = if (len2 < 1e-6f) 0f else (((b.x - ax) * vx + (b.y - ay) * vy) / len2).coerceIn(0f, 1f)
            if (hypot(b.x - (ax + t * vx), b.y - (ay + t * vy)) < (b.r + moverR) * 0.95f) return false
        }
        return true
    }
}
