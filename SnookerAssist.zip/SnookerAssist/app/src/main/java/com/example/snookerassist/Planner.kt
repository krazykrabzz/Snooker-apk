package com.example.snookerassist

import kotlin.math.hypot

data class Shot(
    val cue: Ball, val target: Ball, val pocket: Pocket,
    val ghostX: Float, val ghostY: Float, val score: Float
)

object Planner {
    /** Ghost-ball method in screen space. Prefers reds when any are on the table. */
    fun best(s: Scene): Shot? {
        val cue = s.balls.filter { it.kind == Kind.CUE }.maxByOrNull { it.r } ?: return null
        val others = s.balls.filter { it !== cue }
        if (others.isEmpty()) return null
        val reds = others.filter { it.kind == Kind.RED }
        val targets = if (reds.isNotEmpty()) reds else others
        val r = s.balls.map { it.r }.sorted()[s.balls.size / 2]
        val diag = hypot(s.w.toFloat(), s.h.toFloat())
        var best: Shot? = null

        for (t in targets) for (p in s.pockets) {
            val dx = p.x - t.x; val dy = p.y - t.y
            val d = hypot(dx, dy); if (d < 1e-3f) continue
            val ux = dx / d; val uy = dy / d
            val gx = t.x - ux * 2 * r; val gy = t.y - uy * 2 * r      // ghost ball centre
            val cx = gx - cue.x; val cy = gy - cue.y
            val cd = hypot(cx, cy); if (cd < 1e-3f) continue
            val cosCut = (cx * ux + cy * uy) / cd                      // 1 = straight on
            if (cosCut < 0.17f) continue                               // cut beyond ~80 deg
            val blockers = others.filter { it !== t }
            if (!clear(cue.x, cue.y, gx, gy, blockers, 2 * r * 0.95f)) continue
            if (!clear(t.x, t.y, p.x, p.y, blockers, 2 * r * 0.95f)) continue
            val score = cosCut - 0.5f * (cd + d) / diag
            if (best == null || score > best.score) best = Shot(cue, t, p, gx, gy, score)
        }
        return best
    }

    private fun clear(ax: Float, ay: Float, bx: Float, by: Float, balls: List<Ball>, minDist: Float): Boolean {
        val vx = bx - ax; val vy = by - ay
        val len2 = vx * vx + vy * vy
        for (b in balls) {
            val t = if (len2 < 1e-6f) 0f else (((b.x - ax) * vx + (b.y - ay) * vy) / len2).coerceIn(0f, 1f)
            if (hypot(b.x - (ax + t * vx), b.y - (ay + t * vy)) < minDist) return false
        }
        return true
    }
}
