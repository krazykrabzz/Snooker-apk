package com.example.snookerassist

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.SystemClock
import android.view.WindowManager
import android.widget.Toast

class OverlayService : Service() {
    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var thread: HandlerThread? = null
    private var view: OverlayView? = null
    private val detector = Detector()
    private var last = 0L
    private var frames = 0

    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val code = intent?.getIntExtra("code", 0) ?: 0
        val data = intent?.getParcelableExtra<Intent>("data")
        if (data == null) { stopSelf(); return START_NOT_STICKY }

        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("assist", "Snooker Assist", NotificationManager.IMPORTANCE_LOW))
        val notif = Notification.Builder(this, "assist")
            .setContentTitle("Snooker Assist running")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .build()
        startForeground(1, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)

        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mpm.getMediaProjection(code, data)
        projection?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopSelf() }
        }, Handler(mainLooper))

        // The game runs in landscape but this app's own screen is portrait, so the
        // phone's "current" size here can be the wrong way round. Always capture
        // landscape (long side x short side), otherwise the game gets squashed into
        // a small strip of the capture and nothing is detected.
        val dm = resources.displayMetrics
        val longSide = maxOf(dm.widthPixels, dm.heightPixels)
        val shortSide = minOf(dm.widthPixels, dm.heightPixels)
        val w = (longSide * SCALE).toInt()
        val h = (shortSide * SCALE).toInt()

        // transparent, touch-through overlay that also covers the camera cut-out
        view = OverlayView(this)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        if (Build.VERSION.SDK_INT >= 30) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        } else if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        try {
            (getSystemService(WINDOW_SERVICE) as WindowManager).addView(view, lp)
        } catch (e: Throwable) {
            Toast.makeText(this, "Overlay failed: ${e.message}", Toast.LENGTH_LONG).show()
            stopSelf(); return START_NOT_STICKY
        }
        view?.status = "overlay on, waiting for frames..."

        thread = HandlerThread("capture").also { it.start() }
        val handler = Handler(thread!!.looper)
        reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        display = projection!!.createVirtualDisplay(
            "assist", w, h, dm.densityDpi, DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader!!.surface, null, handler
        )
        reader!!.setOnImageAvailableListener({ r ->
            val img = r.acquireLatestImage() ?: return@setOnImageAvailableListener
            try {
                val now = SystemClock.uptimeMillis()
                if (now - last < 100) return@setOnImageAvailableListener   // ~10 fps
                last = now
                val plane = img.planes[0]
                val buf = plane.buffer
                val rs = plane.rowStride
                val px = IntArray(w * h)
                for (y in 0 until h) for (x in 0 until w) {
                    val i = y * rs + x * 4
                    px[y * w + x] = ((buf.get(i).toInt() and 255) shl 16) or
                        ((buf.get(i + 1).toInt() and 255) shl 8) or (buf.get(i + 2).toInt() and 255)
                }
                var sc: Scene? = null
                var shot: Shot? = null
                val status = try {
                    sc = detector.detect(px, w, h)
                    shot = sc?.let { Planner.best(it) }
                    frames++
                    "f$frames ${w}x$h table=${sc != null} balls=${sc?.balls?.size ?: 0} " +
                        "pockets=${sc?.pockets?.size ?: 0} cue=${sc?.balls?.any { it.kind == Kind.CUE } ?: false} " +
                        "shot=${shot != null}"
                } catch (e: Throwable) {
                    "ERR ${e.javaClass.simpleName}: ${e.message}"
                }
                val fsc = sc
                val fshot = shot
                view?.post {
                    view?.let { it.status = status; it.scene = fsc; it.shot = fshot; it.fw = w; it.fh = h; it.invalidate() }
                }
            } finally {
                img.close()
            }
        }, handler)
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        display?.release(); reader?.close(); projection?.stop(); thread?.quitSafely()
        view?.let { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it) }
        super.onDestroy()
    }

    companion object { const val SCALE = 0.5f }
}
